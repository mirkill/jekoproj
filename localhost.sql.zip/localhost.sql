-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- ����: localhost
-- ����� ��������: ��� 02 2010 �., 19:59
-- ������ �������: 5.0.45
-- ������ PHP: 5.2.4
-- 
-- ��: `jeka`
-- 
CREATE DATABASE `jeka` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE jeka;

-- --------------------------------------------------------

-- 
-- ��������� ������� `clans`
-- 

CREATE TABLE `clans` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL,
  `cl_id` int(2) unsigned NOT NULL,
  `clan_lvl` int(2) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`,`cl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- ���� ������ ������� `clans`
-- 

INSERT INTO `clans` VALUES (5, 'fir', 1, 2);
INSERT INTO `clans` VALUES (6, 'dd', 6, 4);

-- --------------------------------------------------------

-- 
-- ��������� ������� `mail_confirm`
-- 

CREATE TABLE `mail_confirm` (
  `user_id` int(7) unsigned NOT NULL,
  `mail_hash` varchar(32) NOT NULL,
  `day` int(2) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- ���� ������ ������� `mail_confirm`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `notifications`
-- 

CREATE TABLE `notifications` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `user_id` int(5) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `describe` varchar(255) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- ���� ������ ������� `notifications`
-- 

INSERT INTO `notifications` VALUES (2, 2, 'Welcome', 'Your was register in our site', '2010-01-30 06:39:37');
INSERT INTO `notifications` VALUES (3, 3, 'Welcome', 'Your was register in our site', '2010-01-30 07:12:39');
INSERT INTO `notifications` VALUES (4, 4, 'Welcome', 'Your was register in our site', '2010-01-30 08:00:33');
INSERT INTO `notifications` VALUES (5, 4, 'Mail Confirm', 'Yor mail was validated', '2010-01-30 08:02:00');
INSERT INTO `notifications` VALUES (6, 4, 'Profile', 'Yor profile was updated', '2010-01-30 08:05:05');
INSERT INTO `notifications` VALUES (7, 1, 'Profile', 'Yor profile was updated', '2010-02-01 21:23:43');
INSERT INTO `notifications` VALUES (8, 1, 'Profile', 'Yor profile was updated', '2010-02-01 22:06:07');
INSERT INTO `notifications` VALUES (9, 5, 'Welcome', 'Your was register in our site', '2010-02-02 12:56:19');
INSERT INTO `notifications` VALUES (10, 5, 'Profile', 'Yor profile was updated', '2010-02-02 12:57:00');
INSERT INTO `notifications` VALUES (11, 5, 'Mail Confirm', 'Yor mail was validated', '2010-02-02 12:58:08');
INSERT INTO `notifications` VALUES (12, 6, 'Welcome', 'Your was register in our site', '2010-02-02 19:08:25');
INSERT INTO `notifications` VALUES (13, 6, 'Profile', 'Yor profile was updated', '2010-02-02 19:08:54');
INSERT INTO `notifications` VALUES (14, 6, 'Mail Confirm', 'Yor mail was validated', '2010-02-02 19:09:18');

-- --------------------------------------------------------

-- 
-- ��������� ������� `users`
-- 

CREATE TABLE `users` (
  `id` int(7) unsigned NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(15) default NULL,
  `last_name` varchar(20) default NULL,
  `user_role` enum('no_active','user','clan_member','clan_master','admin') default 'no_active',
  `password` varchar(32) NOT NULL,
  `clan_id` int(4) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- ���� ������ ������� `users`
-- 

INSERT INTO `users` VALUES (1, 'login', 'test@test.com', 'jeka2', 'sidelnikov', 'clan_master', 'e10adc3949ba59abbe56e057f20f883e', 5);
INSERT INTO `users` VALUES (2, 'login2', 'test@te2st.com', NULL, NULL, 'no_active', 'e10adc3949ba59abbe56e057f20f883e', NULL);
INSERT INTO `users` VALUES (4, 'MirkiLL', 'to.MegBeg@gmail.com', 'jeka', 'sidelnikov', 'user', 'e10adc3949ba59abbe56e057f20f883e', NULL);
INSERT INTO `users` VALUES (5, 'fk1', 'test@tedst.com', 'kiril', 'dyrko', 'user', 'e10adc3949ba59abbe56e057f20f883e', NULL);
INSERT INTO `users` VALUES (6, 'jk14', 'test@tesdst.com', 'E', 'S', 'clan_master', 'e10adc3949ba59abbe56e057f20f883e', 6);
